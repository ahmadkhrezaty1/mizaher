<?php
/*
Plugin Name: Wordpess Self-hosted Authentication
Plugin URI:
Description: Allows access to WP to write posts from remote server using authentication key and user key.
Version: 1.0.0
Author: 
Author URI:
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

function xit_sh_auth_init() {
	// Generates rewrite rules
	xit_sh_auth_register_rewrites();
	
    global $wp;
    
	// Adds some query vars
	$wp->add_query_var( 'xit_sh_auth' );
}
add_action( 'init', 'xit_sh_auth_init' );

function xit_sh_auth_register_rewrites() {
	add_rewrite_rule( 'xit-sh-endpoint/post', 'index.php?xit_sh_auth=post', 'top' );
}

function xit_sh_auth_and_post() {
    $xit_sh_auth = filter_var( get_query_var( 'xit_sh_auth' ), FILTER_SANITIZE_STRING );
    if ( 'post' == $xit_sh_auth ) {
        if ( $_POST ) {
            // Checks if user and authentication keys exist
            $post_keys = array_keys($_POST);
            
            if ( ! in_array( 'user_key', $post_keys ) || ! in_array( 'authentication_key', $post_keys ) ) {
                echo json_encode([
                    'status' => 401,
                    'message' => __( 'Unauthorized', 'xit_wp_sh_auth' ),
                ]);
                exit;  
            }
            
            $user_key = isset( $_POST[ 'user_key' ] ) ? filter_var( $_POST['user_key'], FILTER_SANITIZE_STRING ) : null;
            $auth_key = isset( $_POST[ 'authentication_key' ] ) ? filter_var( $_POST['authentication_key'], FILTER_SANITIZE_STRING ) : null;
            $meta_key = "xit_wp_sh_auth_key_{$user_key}";
            
            global $wpdb;
            $value = $wpdb->get_var( $wpdb->prepare("SELECT meta_value FROM $wpdb->usermeta WHERE meta_key = %s AND meta_value = %s LIMIT 1" , $meta_key, $auth_key ) );
            
            if ( null === $value ) {
                echo json_encode([
                    'status' => 401,
                    'message' => __( 'Unauthorized', 'xit_wp_sh_auth' ),
                ]);
                exit;
            }
            
            // Tries to insert post into database
            $result = xit_wp_sh_wp_insert_post();
            
            if ( ! is_array( $result ) && ! count( $result ) > 0 ) {
                echo json_encode([
                    'status' => 4000,
                    'message' => __( 'Bad request', 'xit_wp_sh_auth' ),
                ]);
                exit;
            }
            
            echo json_encode([
                'status' => 200,
                'message' => __( 'OK', 'xit_wp_sh_auth' ),
            ]);
            exit;
        } else {
            echo json_encode([
                'status' => 4000,
                'message' => __( 'Bad request', 'xit_wp_sh_auth' ),
            ]);
            exit;
        }
    }
}
add_action( 'template_redirect', 'xit_sh_auth_and_post' );

function xit_wp_sh_wp_insert_post() {
    
    if ( empty( $_POST ) ) {
        return null;
    }
    
    // Prepares some vars
    $type = isset( $_POST['type'] ) ? $_POST['type'] : null;
    $user_key = isset( $_POST['user_key'] ) ? $_POST['user_key'] : null;
    $post_author = is_string( $user_key ) ? base64_decode( $user_key ) : null;
    $post_author = is_string( $post_author ) ? substr( $post_author, strlen( 'xit_sh_user_key_' ) ) : '0';
    $media_url = isset( $_POST['media_url'] ) ? $_POST['media_url'] : '';
    
    // Decides post type and its content
    $file_url = '';
    $post_mime_type = '';
    
    if ( 'text' == $type ) {
        $post_content = isset( $_POST['post_content'] ) ? strip_tags( $_POST['post_content'] ) : '';
    } elseif ( 'html' == $type ) {
        $post_content = isset( $_POST['post_content'] ) ? wp_kses_post( html_entity_decode( $_POST['post_content'] ) ) : '';
    } elseif ( 'image' == $type ) {
        $post_content = isset( $_POST['post_content'] ) ? strip_tags( $_POST['post_content'] ) : '';
        
        // Uploads attachment
        if ( ! empty( $media_url ) ) {
            $status = xit_wp_sh_upload_attachment( $media_url );
            if ( is_array( $status ) ) {
                $file_url = isset( $status['file_url'] ) ? $status['file_url'] : '';
                $post_mime_type = isset( $status['post_mime_type'] ) ? $status['post_mime_type'] : '';
            }
        }

    } elseif ( 'video' == $type ) {
        $post_content = isset( $_POST['post_content'] ) ? strip_tags( $_POST['post_content'] ) : '';
        
        // Uploads attachment
        if ( ! empty( $media_url ) ) {
            $status = xit_wp_sh_upload_attachment( $media_url );
            if ( is_array( $status ) ) {
                $file_url = isset( $status['file_url'] ) ? $status['file_url'] : '';
                $post_mime_type = isset( $status['post_mime_type'] ) ? $status['post_mime_type'] : '';
            }
        }      
    } else {
        $post_content = isset( $_POST['post_content'] ) ? strip_tags( $_POST['post_content'] ) : '';
    }
    
    // Prepares post vars
    $post_title = isset( $_POST['post_title'] ) ? sanitize_text_field( $_POST['post_title'] ) : '';
    $post_status = isset( $_POST['post_status'] ) ? sanitize_key( $_POST['post_status'] ) : 'publish';
    $comment_status = isset( $_POST['comment_status'] ) ? sanitize_key( $_POST['comment_status'] ) : 'open';
    $post_name = isset( $_POST['post_title'] ) ? sanitize_title( $_POST['post_title'] ) : '';
    $post_category = isset( $_POST['post_category'] ) ? $_POST['post_category'] : [];
    $tags_input = isset( $_POST['tags_input'] ) ? $_POST['tags_input'] : [];
    
    // prepares post data
    $post_data = [
        'post_author'=> (int) $post_author,
        'post_content' => $post_content,
        'post_title' => $post_title,
        'post_status' => $post_status,
        'post_type' => 'post',
        'comment_status' => $comment_status,
        'post_name' => $post_name,
        'post_category' => $post_category,
        'tags_input' => $tags_input,
    ];
    
    // Tries to insert post into database
    $post_id = wp_insert_post( $post_data, true );
    
    // Updates attachment post type
    if ( $post_id && $file_url && $post_mime_type ) {
        $data = [
            'type' => $type,
            'post_id' => $post_id,
            'post_title' => $post_title,
            'post_author' => (int) $post_author,
            'post_content' => $post_content,
            'file_url' => $file_url,
            'post_mime_type' => $post_mime_type,
        ];
        
        xit_wp_sh_insert_attachement( $data );
    }
    
    $result = [];
    if ( $post_id > 0 ) {
        global $wpdb;
        $result = $wpdb->get_results( 
            $wpdb->prepare("SELECT post_title, post_name, guid FROM $wpdb->posts WHERE ID = %d LIMIT 1" , $post_id ),
            ARRAY_A
        );
        
        if (is_array( $result ) && count( $result ) > 0 ) {
            $result = $result[0];
        }
    }
    
    return [
        'post_id' => $post_id,
        'post_title' => isset( $result['post_title'] ) ? $result['post_title'] : '',
        'post_name' => isset( $result['post_name'] ) ? $result['post_name'] : '',
        'url' => isset( $result['guid'] ) ? $result['guid'] : '',
    ];
}

function xit_wp_sh_upload_attachment( $url ) {
    $basename = basename( parse_url( $url, PHP_URL_PATH ) );
    $sanitized_basename = filter_var( $basename, FILTER_SANITIZE_STRING );
    
    $wp_upload_path = wp_upload_dir();
    $new_file_abspath = $wp_upload_path['path'] . DIRECTORY_SEPARATOR . $sanitized_basename;
    
    // Moves the file to destination
    $uploaded = false;
    $old_file = @fopen( $url, 'rb' );
    if ( $old_file ) {
        $new_file = @fopen( $new_file_abspath, 'wb' );
        if ( $new_file ) {
            while ( ! feof( $old_file ) ) {
                fwrite( $new_file, fread( $old_file, 1024 * 10 ), 1024 * 10 );
            }
            
            $uploaded = true;
            fclose( $new_file );
        }
        fclose( $old_file );
    }
    
    if ( true === $uploaded ) {
        $file_url = $wp_upload_path['url'] . DIRECTORY_SEPARATOR . $sanitized_basename;
        $post_mime_type = mime_content_type( $new_file_abspath );
        
        return [ 
            'file_url' => $file_url, 
            'post_mime_type' => $post_mime_type 
        ];
    }
    
    return null;
}

function xit_wp_sh_insert_attachement( $data ) {
    // Prepare an array of post data for the attachment.
    $attachment = array(
        'guid'           => $data['file_url'], 
        'post_mime_type' => $data['post_mime_type'],
        'post_author'    => $data['post_author'],
        'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $data['file_url'] ) ),
        'post_content'   => $data['post_content'],
        'post_status'    => 'inherit'
    );
     
    // Insert the attachment.
    $attach_id = wp_insert_attachment( $attachment, $data['file_url'], $data['post_id'] );
     
    // Make sure that this file is included, as wp_generate_attachment_metadata() depends on it.
    require_once( ABSPATH . 'wp-admin/includes/image.php' );
    require_once( ABSPATH . 'wp-admin/includes/file.php' );
    require_once( ABSPATH . 'wp-admin/includes/media.php' );
     
    // Generate the metadata for the attachment, and update the database record.
    $attach_data = wp_generate_attachment_metadata( $attach_id, $data['file_url'] );
    wp_update_attachment_metadata( $attach_id, $attach_data );
    
    if ( 'image' == $data['type'] ) {
        set_post_thumbnail( $data['post_id'], $attach_id );    
    } 
}

function xit_wp_sh_authentication_field( $user ) {
    
    if ( ! current_user_can( 'administrator', $user->ID ) ) {
        return false;    
    }
    
	$hashed_user_id = base64_encode( 'xit_sh_user_key_' . $user->ID );
	$auth_meta_key = 'xit_wp_sh_auth_key_' . $hashed_user_id;
	$xit_wp_sh_auth_key = get_user_meta($user->ID, $auth_meta_key, true);
	?>
	<h3><?php esc_html_e( 'Wordpress Self-hosted Authentication', 'xit_wp_sh_auth' ); ?></h3>
	<p class="description"><?php echo esc_html_e( 'Expects a post request with "user_key", "authentication_key" and post data.', 'xit_wp_sh_auth' ); ?></p>

	<table class="form-table">
		<tr>
			<th><label for="xit_wp_sh_auth_key_<?php echo $hashed_user_id; ?>"><?php esc_html_e( 'Authentication Key', 'xit_wp_sh_auth' ); ?></label></th>
			<td>
				<input type="text"
			       id="xit_wp_sh_auth_key_<?php echo $hashed_user_id; ?>"
			       name="xit_wp_sh_auth_key_<?php echo $hashed_user_id; ?>"
			       value="<?php echo esc_attr( $xit_wp_sh_auth_key ); ?>"
			       class="regular-text"
				/>
				<p class="description"><?php echo esc_html_e( 'Put in the Authentication Key which is available from where you get this plugin.', 'xit_wp_sh_auth' ); ?></p>
			</td>
		</tr>
		<tr>
			<th><label for="xit_wp_sh_user_key"><?php esc_html_e( 'User Key', 'xit_wp_sh_auth' ); ?></label></th>
			<td>
				<input type="text"
			       id="xit_wp_sh_user_key"
			       name="xit_wp_sh_user_key"
			       value="<?php echo esc_attr( $hashed_user_id ); ?>"
			       class="regular-text"
			       disabled
				/>
				<p class="description"><?php echo esc_html_e( 'Copy this code and put in the box below where you get the Authentication Key.', 'xit_wp_sh_auth' ); ?></p>
			</td>
		</tr>		
	</table>
	<?php
}

add_action( 'show_user_profile', 'xit_wp_sh_authentication_field' );
add_action( 'edit_user_profile', 'xit_wp_sh_authentication_field' );

// function xit_sh_auth_user_profile_update_errors( $errors, $update, $user ) {

//     if ( ! current_user_can( 'administrator', $user->ID ) ) {
//         return false;    
//     }
    
// 	if ( ! $update ) {
// 		return;
// 	}
	
// 	$hashed_user_id = base64_encode( 'xit_sh_user_key_' . $user->ID );
//     $post_name = "xit_wp_sh_auth_key_{$hashed_user_id}";
    
// 	if ( empty( $_POST[$post_name] ) ) {
// 		$errors->add( 'wp_sh_auth_error', __( '<strong>ERROR</strong>: Please enter your authentication key.', 'xit_wp_sh_auth' ) );
// 	}
// }

// add_action( 'user_profile_update_errors', 'xit_sh_auth_user_profile_update_errors', 10, 3 );

function xit_sh_auth_update_profile_field( $user_id ) {
    
    if ( ! current_user_can( 'administrator', $user_id ) ) {
        return false;    
    }

	$hashed_user_id = base64_encode( 'xit_sh_user_key_' . $user_id );
    $post_name = "xit_wp_sh_auth_key_{$hashed_user_id}";
    
	if ( ! empty( $_POST[$post_name] ) && filter_var( $_POST[$post_name], FILTER_SANITIZE_STRING ) ) {
		update_user_meta( $user_id, $post_name, $_POST[$post_name] );
	}
}
add_action( 'personal_options_update', 'xit_sh_auth_update_profile_field' );
add_action( 'edit_user_profile_update', 'xit_sh_auth_update_profile_field' );

function xit_sh_auth_activation( $network_wide ) {
	if ( function_exists( 'is_multisite' ) && is_multisite() && $network_wide ) {

		$mu_blogs = wp_get_sites();

		foreach ( $mu_blogs as $mu_blog ) {
			switch_to_blog( $mu_blog['blog_id'] );
			xit_sh_auth_register_rewrites();
			flush_rewrite_rules();
		}

		restore_current_blog();
	} else {
		xit_sh_auth_register_rewrites();
		flush_rewrite_rules();
	}
}
register_activation_hook( __FILE__, 'xit_sh_auth_activation' );

function xit_sh_auth_deactivation( $network_wide ) {
	if ( function_exists( 'is_multisite' ) && is_multisite() && $network_wide ) {

		$mu_blogs = wp_get_sites();

		foreach ( $mu_blogs as $mu_blog ) {
			switch_to_blog( $mu_blog['blog_id'] );
			flush_rewrite_rules();
		}

		restore_current_blog();
	} else {
		flush_rewrite_rules();
	}
}
register_deactivation_hook( __FILE__, 'xit_sh_auth_deactivation' );
